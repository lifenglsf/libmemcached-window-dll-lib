
#pragma once

#define LIBHASHKIT_VERSION_STRING "1.0.0"
#define LIBHASHKIT_VERSION_HEX 0x01000000

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
